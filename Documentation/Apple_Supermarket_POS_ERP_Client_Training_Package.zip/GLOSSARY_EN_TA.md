# Standardized Retail & ERP Terminology Glossary (English – Tamil)
# சில்லறை வணிகம் மற்றும் ஈஆர்பி கலைச்சொல் களஞ்சியம்

This glossary is the authoritative single source of truth for terminology across all user manuals, video scripts, subtitles, and interactive training modules for the Apple Supermarket POS & ERP Platform.

---

## 1. Core POS & Counter Operations (பில்லிங் மற்றும் விற்பனை கவுண்டர்)

| English Term | Tamil Term | Tamil Transliteration / Practical Usage | Meaning & Context |
| :--- | :--- | :--- | :--- |
| **Point of Sale (POS)** | விற்பனை முனை முனையம் / பில்லிங் கவுண்டர் | Point of Sale / Billing Counter | The physical or digital checkout terminal where customer sales transactions are processed. |
| **Billing / Invoice** | விற்பனை ரசீது / பில் | Invoice / Bill | Commercial sales receipt given to customers listing items, taxes, and totals. |
| **Barcode Scanner** | பார்கோடு ஸ்கேனர் | Barcode Scanner | Optical scanner used to read EAN-13, UPC, or QR barcodes quickly at checkout. |
| **Cart / Line Item** | வாங்கும் பொருட்கள் பட்டியல் / உருப்படி | Cart Items / Line Item | Products added to the customer's current billing order. |
| **Hold Cart** | பில்லை நிறுத்திவைத்தல் | Hold Bill / Cart Hold | Temporarily parking a customer's active cart while they fetch more items. |
| **Recall Cart** | நிறுத்திய பில்லை மீட்டெடுத்தல் | Recall / Resume Bill | Retrieving a held cart to finish billing. |
| **Tender / Payment Mode** | கட்டணம் செலுத்தும் முறை | Payment Mode (Cash, Card, UPI) | Split or single payment methods accepted at the checkout. |
| **Cash Drawer** | ரொக்கப் பெட்டகம் | Cash Drawer | Hardware cash drawer connected to the POS printer that opens automatically upon payment. |
| **Shift Report** | ஷிப்ட் கணக்கு அறிக்கை | Shift Reconciliation Report | End-of-shift summary of cash collected, UPI transactions, card payments, and refunds. |
| **End of Day (EOD)** | நாள் முடிவு அறிக்கை / நாள் நிறைவு | Day Close / EOD Reconciliation | Closing of daily business accounts across all counters and reconciling net revenue. |

---

## 2. Inventory, Warehouse & Supply Chain (சரக்கு மற்றும் கிடங்கு மேலாண்மை)

| English Term | Tamil Term | Tamil Transliteration / Practical Usage | Meaning & Context |
| :--- | :--- | :--- | :--- |
| **Product Catalog** | பொருட்கள் பட்டியல் | Product Catalog / Master List | Master repository of all SKUs, descriptions, HSN codes, and tax slabs. |
| **SKU (Stock Keeping Unit)** | சரக்கு குறியீட்டு எண் | SKU / Item Code | Unique identification code assigned to each distinct product item. |
| **Stock Ledger** | சரக்கு இருப்புப் பதிவேடு | Stock Ledger | Immutable chronological audit trail of all stock movements (In, Out, Adjustments). |
| **Stock Position** | தற்போதைய இருப்பு நிலை | Current Stock Position | Real-time on-hand quantity of all items in store and warehouse locations. |
| **Goods Receipt Note (GRN)** | சரக்கு வரவு ரசீது | GRN (Goods Receipt) | Inward document acknowledging verification and receipt of goods delivered by suppliers. |
| **Purchase Order (PO)** | கொள்முதல் ஆணை | Purchase Order (PO) | Formal commercial document sent to suppliers requesting replenishment of inventory. |
| **Stock Adjustment** | இருப்பு சரிசெய்தல் | Stock Adjustment | Correcting stock counts due to wastage, expiration, damage, or discrepancy. |
| **Stock Take / Physical Audit** | நேரடி சரக்கு தணிக்கை | Physical Stock Audit / Verification | Physical counting of store inventory to compare against system quantities. |
| **Warehouse / Bin Location** | கிடங்கு மற்றும் அடுக்கு இருப்பிடம் | Warehouse Rack & Bin Location | Specific shelf, aisle, or bin location where products are stored. |
| **Reorder Point (ROP)** | மறுஆர்டர் நிலை | Reorder Level | Minimum threshold quantity at which automatic replenishment is triggered. |

---

## 3. Pricing, Offers & Promotions (விலை நிர்ணயம் மற்றும் சலுகைகள்)

| English Term | Tamil Term | Tamil Transliteration / Practical Usage | Meaning & Context |
| :--- | :--- | :--- | :--- |
| **MRP (Maximum Retail Price)** | அதிகபட்ச சில்லறை விலை | MRP | Printed maximum retail price under statutory regulations. |
| **Selling Price (RSP)** | விற்பனை விலை | Selling Price / Retail Price | Actual price offered to the consumer after supermarket margin discount. |
| **Purchase Price / Cost Price** | கொள்முதல் விலை | Cost Price (Landing Cost) | Cost per unit paid to the distributor/supplier including taxes and freight. |
| **Promotions / Offers** | சிறப்பு தள்ளுபடி சலுகைகள் | Offers & Promotions | Marketing deals configured to boost sales volume. |
| **Buy-One-Get-One (BOGO)** | ஒன்றிற்கு ஒன்று இலவசம் | Buy 1 Get 1 Free | Promotional deal where purchasing one unit gives another unit free. |
| **Bundle / Combo Offer** | தொகுப்புச் சலுகை | Combo Pack Discount | Special pricing applied when purchasing complementary product groups. |
| **Price Tier** | பலநிலை விலை அடுக்கு | Price Tier / Slab | Volume-based pricing (e.g., retail price vs. bulk carton price). |

---

## 4. CRM & Customer Loyalty (வாடிக்கையாளர் உறவு மற்றும் விசுவாசப் புள்ளிகள்)

| English Term | Tamil Term | Tamil Transliteration / Practical Usage | Meaning & Context |
| :--- | :--- | :--- | :--- |
| **Customer Master** | வாடிக்கையாளர் விபரம் | Customer Profile / Master | Database of customer phone numbers, names, purchase history, and credit balance. |
| **Loyalty Points** | விசுவாசப் புள்ளிகள் / வெகுமதிப் புள்ளிகள் | Loyalty Reward Points | Points accrued by shoppers on every eligible transaction. |
| **Points Redemption** | புள்ளிகள் கழிவு / மீட்டெடுத்தல் | Points Redemption | Applying accumulated points as cash discounts during POS checkout. |
| **Customer Tier** | வாடிக்கையாளர் அடுக்கு (சில்வர் / கோல்ட் / பிளாட்டினம்) | Customer Tier (Silver/Gold/Platinum) | Customer classification based on monthly/annual shopping spend. |
| **Store Credit / Khata** | வாடிக்கையாளர் கடன் கணக்கு (காதா) | Store Credit / Credit Ledger | Recorded ledger for trusted regular customers purchasing on monthly credit. |

---

## 5. Finance & Accounting (நிதி மற்றும் கணக்கியல்)

| English Term | Tamil Term | Tamil Transliteration / Practical Usage | Meaning & Context |
| :--- | :--- | :--- | :--- |
| **Chart of Accounts (COA)** | கணக்கு வகை அட்டவணை | Chart of Accounts | Structured classification of Assets, Liabilities, Equity, Revenue, and Expenses. |
| **General Ledger (GL)** | பொதுப் பேரேடு | General Ledger | Master ledger recording all debit and credit accounting entries. |
| **Accounts Payable (AP)** | செலுத்த வேண்டிய தொகை (சப்ளையர் பில்கள்) | Accounts Payable (Supplier Dues) | Outstanding payments owed by the supermarket to suppliers and vendors. |
| **Accounts Receivable (AR)** | பெற வேண்டிய தொகை (வாடிக்கையாளர் பாக்கி) | Accounts Receivable (Customer Dues) | Money owed to the supermarket by corporate or credit customers. |
| **Profit & Loss (P&L)** | லாப நஷ்ட அறிக்கை | Profit & Loss Statement | Financial statement detailing revenues, costs of goods sold, expenses, and net profit. |
| **Balance Sheet** | இருப்புநிலைக் குறிப்பு | Balance Sheet | Statement of financial position showing company assets, liabilities, and equity. |
| **Trial Balance** | இருப்பாய்வு | Trial Balance | Worksheet verifying that total debits equal total credits across all accounts. |
| **Aging Analysis** | காலாவதி காலம் சார்ந்த நிலுவை அறிக்கை | AP/AR Aging Analysis | Categorization of overdue payables and receivables by age brackets (0-30, 31-60, 90+ days). |

---

## 6. AI Co-Pilot & Business Intelligence (செயற்கை நுண்ணறிவு வழிகாட்டி)

| English Term | Tamil Term | Tamil Transliteration / Practical Usage | Meaning & Context |
| :--- | :--- | :--- | :--- |
| **AI Co-Pilot** | ஏஐ ஸ்மார்ட் வழிகாட்டி | AI Co-Pilot Assistant | Natural-language intelligent assistant helping managers analyze operations. |
| **Demand Forecasting** | தேவை முன்னறிவிப்பு | Demand Forecasting | Machine learning algorithm predicting future sales volume based on seasonality and trends. |
| **Smart Markdowns** | ஸ்மார்ட் விலை குறைப்பு பரிந்துரை | Smart Expiry Markdowns | Automated suggestions to discount nearing-expiry stock to avoid wastage. |
| **Loss Prevention / Fraud Detection** | திருட்டு மற்றும் இழப்பு தடுப்பு முறை | Loss Prevention / Anomaly Alert | Automated alert system detecting suspicious voids, unauthorized discounts, or cash mismatches. |
| **AI Invoice Extractor** | ஏஐ பில் தானியங்கி படிப்பு முறை | AI Invoice OCR Extractor | Computer vision & OCR engine that scans printed supplier invoices into GRN drafts automatically. |
| **Executive Dashboard** | நிர்வாக மேலாண்மைத் தகவல் பலகை | Executive Dashboard | Top-level KPI screen summarizing revenue, gross margin, top-selling SKUs, and store health. |
