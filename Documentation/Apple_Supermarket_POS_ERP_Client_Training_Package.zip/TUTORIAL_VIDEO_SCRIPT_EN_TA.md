# End-to-End Product Walkthrough & Training Video Script (English & Tamil)
# முழுமையான தயாரிப்பு விளக்க மற்றும் பயிற்சி காணொளி வசனத் தொகுப்பு

**Product:** Apple Supermarket Enterprise POS & ERP Platform  
**Target Audience:** Prospective Supermarket Owners, Chain Store Executives, Store Managers, Chief Cashiers, and Accountants.  
**Languages:** English & Tamil (தமிழ்)  
**Standardized Glossary:** Strict adherence to [`GLOSSARY_EN_TA.md`](./GLOSSARY_EN_TA.md)  
**Video Output Format:** High-Definition WebM (`Documentation/videos/supermarket_erp_walkthrough.webm`)  

> [!NOTE]
> **Voiceover & Speech Synthesis Notice:**
> The accompanying interactive tutorial player features automated speech preview. Because browser-based Web Speech API Tamil text-to-speech (TTS) voices vary across operating systems and client devices, a **synchronized subtitle and caption banner** is built directly into every screen. For public television, YouTube, or high-stakes investor broadcasts, use the side-by-side script below with a professional human voiceover artist.

---

## Video Chapter Outline

1. **Chapter 1 (00:00 - 01:30):** System Introduction, Architecture & Role-Based Security
2. **Chapter 2 (01:30 - 04:30):** High-Speed POS Counter Billing & Cashier Operations
3. **Chapter 3 (04:30 - 07:00):** Inventory, Goods Receipt Note (GRN), PO & Stock Auditing
4. **Chapter 4 (07:00 - 09:30):** CRM, Customer Loyalty Points & Dynamic Offers Engine
5. **Chapter 5 (09:30 - 12:00):** Complete Financial Accounting (P&L, Balance Sheet, AP/AR Ledgers)
6. **Chapter 6 (12:00 - 14:00):** AI Co-Pilot Intelligence, Demand Forecasting & Loss Prevention

---

## Chapter 1: System Introduction & Security (அறிமுகம் மற்றும் பாதுகாப்பு)
**Timing:** 00:00 – 01:30  
**Screen Visual:** High-resolution view of the login portal (`01_login.png`) showing role badges (Owner, Manager, Cashier, Accountant), followed by the Executive Dashboard (`02_dashboard.png`).

| On-Screen Action & Visual Cues | English Voiceover Narration | Tamil Voiceover Narration (தமிழ்) |
| :--- | :--- | :--- |
| **Visual:** Camera zooms into the modern, dark-mode login terminal. Mouse selects the store branch and role.<br>**Text Overlay:** *Enterprise-Grade Multi-Tenant Supermarket ERP* | Welcome to the Apple Supermarket Enterprise POS & ERP Platform — a modern, unified software suite built specifically for high-volume retail supermarkets and multi-branch grocery chains. | வணக்கம்! ஆப்பிள் சூப்பர்மார்க்கெட் என்டர்பிரைஸ் பி.ஓ.எஸ் மற்றும் ஈஆர்பி தளத்திற்கு உங்களை அன்புடன் வரவேற்கிறோம். இது அதிக வாடிக்கையாளர்கள் வரும் பல்பொருள் அங்காடிகள் மற்றும் பல கிளைகளைக் கொண்ட மளிகைக் கடைகளுக்காகவே பிரத்யேகமாக உருவாக்கப்பட்ட அதிநவீன மென்பொருளாகும். |
| **Visual:** User authenticates with role PIN. Smooth transition into the Executive Dashboard displaying real-time gross revenue, sales trends, and live store health.<br>**Text Overlay:** *Strict Role-Based Access Control* | With strict role-based security, your system segregates duties seamlessly between Store Owners, Branch Managers, Cashiers, and Accountants. Owners gain 360-degree visibility over live sales, profit margins, and counter speeds from anywhere in the world. | இதில் உள்ள பாதுகாப்பான பொறுப்பு சார்ந்த அணுகல் முறை (Role-Based Access) மூலம், கடையின் உரிமையாளர், மேலாளர், காசாளர் மற்றும் கணக்காளர் என ஒவ்வொருவருக்கும் தனித்தனி கட்டுப்பாடுகள் வழங்கப்படுகின்றன. உரிமையாளர்கள் தங்கள் கடையின் நேரடி விற்பனை, லாப விகிதம் மற்றும் கவுண்டர் செயல்பாடுகளை உலகின் எந்த மூலையிலிருந்தும் நொடியில் கண்காணிக்க முடியும். |

---

## Chapter 2: POS Counter Billing & Cashier Operations (பில்லிங் மற்றும் விற்பனை கவுண்டர்)
**Timing:** 01:30 – 04:30  
**Screen Visual:** POS Terminal (`03_pos_billing.png`), Barcode scanning, item list, hold cart popup, tender payment modal, and thermal receipt printout.

| On-Screen Action & Visual Cues | English Voiceover Narration | Tamil Voiceover Narration (தமிழ்) |
| :--- | :--- | :--- |
| **Visual:** Cashier scans 4 grocery items. Products, quantity, and GST calculate instantly in under 40 milliseconds.<br>**Text Overlay:** *Sub-50ms Ultra-Fast Barcode Scanning* | At the checkout counter, speed is everything. Our POS terminal is engineered for sub-50 millisecond response times. Cashiers can scan barcodes effortlessly, search loose produce by weight, and apply customer telephone numbers for instant loyalty lookups. | விற்பனை கவுண்டரில் வேகம் தான் மிக முக்கியம். எங்கள் பில்லிங் கவுண்டர் 50 மில்லி விநாடிக்கும் குறைவான வேகத்தில் செயல்படும் திறன் கொண்டது. காசாளர்கள் பார்கோடுகளை விரைவாக ஸ்கேன் செய்யலாம், எடை கொண்ட காய்கறி பொருட்களை எளிதாகத் தேர்ந்தெடுக்கலாம் மற்றும் வாடிக்கையாளரின் தொலைபேசி எண்ணை உள்ளிட்டு உடனடியாக பில் செய்யலாம். |
| **Visual:** Customer realizes they forgot butter. Cashier hits `F6` (Hold Cart). Next customer's items are scanned and billed. Held cart is retrieved in 1 click.<br>**Text Overlay:** *Zero Queue Delays: Instant Hold & Recall* | Long queues? Never again. If a shopper steps away, simply press 'Hold Bill'. The cashier immediately serves the next customer, and recalls the original cart with a single hotkey when the shopper returns — zero data loss, zero frustration. | நீண்ட வரிசையா? கவலையே வேண்டாம். ஒரு வாடிக்கையாளர் கூடுதல் பொருள் எடுக்கச் சென்றால், 'பில்லை நிறுத்திவைத்தல்' (Hold Bill) வசதியைப் பயன்படுத்தலாம். அடுத்த வாடிக்கையாளருக்கு உடனடியாக பில் போட்டுவிட்டு, முந்தைய வாடிக்கையாளர் வந்ததும் ஒரே கிளிக்கில் அந்த பில்லை மீட்டெடுத்து (Recall Bill) முடிக்க முடியும். |
| **Visual:** Payment options pop up showing Cash, Card, and UPI QR code. Split tender: ₹500 in Cash and ₹350 via UPI. Cash drawer opens, thermal receipt prints.<br>**Text Overlay:** *Multi-Tender Split Payments & Instant Thermal Print* | The POS natively supports split tender: pay partially in Cash, Card, and UPI QR code. Loyalty points are automatically redeemed as instant discounts. Once tendered, the cash drawer triggers automatically, and the invoice prints on standard 3-inch ESC/POS thermal printers. | இதில் ரொக்கம் (Cash), கார்டு (Card) மற்றும் யு.பி.ஐ க்யூ.ஆர் (UPI QR) என பல வழிகளில் ஒரே பில்லுக்கு பிரித்துக் கட்டணம் பெறலாம் (Split Payment). வாடிக்கையாளரின் விசுவாசப் புள்ளிகளை (Loyalty Points) நேரடி தள்ளுபடியாகக் கழிக்கலாம். கட்டணம் முடிந்ததும் ரொக்கப் பெட்டகம் தானாகத் திறக்கும், உடனே 3-இன்ச் தெர்மல் ரசீதும் அச்சிடப்படும். |
| **Visual:** Cashier shift closes at 2:00 PM (`04_shift_report.png`). Screen shows Cash reconciliation, actual vs. expected drawer balance.<br>**Text Overlay:** *End-of-Shift Reconciliation & Blind Cash Drop* | At the end of every shift, the system generates a tamper-evident Shift Reconciliation Report. Cashiers perform a blind cash drop, eliminating till shortages and ensuring 100% accountability before the evening shift takes over. | ஒவ்வொரு ஷிப்ட் முடிவிலும், கணக்குகளைத் துல்லியமாக சரிபார்க்கும் ஷிப்ட் அறிக்கை (Shift Report) தயாராகிறது. காசாளர்கள் வசூலான பணத்தை எண்ணி ஒப்படைக்கும் போது, கணக்கில் எந்தவித முரண்பாடும் இன்றி 100% வெளிப்படைத்தன்மை உறுதி செய்யப்படுகிறது. |

---

## Chapter 3: Inventory, GRN & Purchasing (சரக்கு, கொள்முதல் மற்றும் ஜி.ஆர்.என்)
**Timing:** 04:30 – 07:00  
**Screen Visual:** Product Catalog (`05_product_catalog.png`), Price Management (`06_price_management.png`), Purchase Orders (`07_purchase_orders.png`), and Goods Receipt Note (`08_inventory_grn.png`).

| On-Screen Action & Visual Cues | English Voiceover Narration | Tamil Voiceover Narration (தமிழ்) |
| :--- | :--- | :--- |
| **Visual:** Manager navigates to the Master Product Catalog. Search filters by category, brand, and HSN code. Bulk CSV import button highlighted.<br>**Text Overlay:** *Master SKU Catalog & Automated Barcoding* | Managing thirty thousand supermarket SKUs has never been simpler. The catalog centralizes MRP, selling price, landing cost, tax slabs, and warehouse bin locations. You can bulk-import supplier catalogs via CSV in seconds. | முப்பதாயிரத்திற்கும் மேற்பட்ட சூப்பர்மார்க்கெட் பொருட்களை நிர்வகிப்பது இப்போது மிக எளிது. எம்.ஆர்.பி (MRP), விற்பனை விலை, கொள்முதல் விலை, ஜிஎஸ்டி வரி விகிதங்கள் மற்றும் கிடங்கு அடுக்கு இருப்பிடங்களை ஒரே இடத்தில் பராமரிக்கலாம். சப்ளையர் பட்டியலை சி.எஸ்.வி (CSV) மூலம் நொடிகளில் பதிவேற்ற முடியும். |
| **Visual:** Supplier PO created for dairy products. Supplier delivers goods. Manager opens Goods Receipt Note (GRN) screen, verifying delivered quantity vs PO.<br>**Text Overlay:** *Three-Way Matched Goods Receipt Note (GRN)* | When suppliers deliver stock, the Goods Receipt Note module performs automated 3-way matching between the Purchase Order, Supplier Invoice, and physically received quantities. Any damage or short shipment is instantly flagged. | சப்ளையர் சரக்குகளைக் கொண்டு வரும் போது, சரக்கு வரவு ரசீது (GRN) மூலம் கொள்முதல் ஆணை (PO), சப்ளையர் பில் மற்றும் வந்திறங்கிய சரக்குகள் ஆகிய மூன்றையும் எளிதாக ஒப்பிட்டு சரிபார்க்கலாம். சேதமடைந்த அல்லது விடுபட்ட பொருட்கள் உடனடியாகக் கண்டறியப்படும். |
| **Visual:** GRN is confirmed. Stock Ledger (`09_stock_ledger.png`) updates in real-time. Store stock position rises immediately without manual double-entry.<br>**Text Overlay:** *Real-Time Stock Position & Immutable Ledger* | The moment the GRN is approved, warehouse inventory and store shelves update in real-time. An immutable Stock Ledger records every movement with user timestamp and batch details, completely eliminating phantom inventory and pilferage. | ஜி.ஆர்.என் அங்கீகரிக்கப்பட்ட அடுத்த நொடியே, கிடங்கு மற்றும் கடையில் உள்ள இருப்பு தானாக உயர்ந்துவிடும். முழுமையான சரக்கு இருப்புப் பதிவேட்டில் (Stock Ledger) தேதி, நேரம் மற்றும் பேட்ச் விபரங்களுடன் பதிவாவதால், சரக்கு திருட்டு மற்றும் இழப்புகள் முற்றிலும் தடுக்கப்படுகின்றன. |

---

## Chapter 4: CRM, Loyalty & Promotions (வாடிக்கையாளர் விசுவாசம் மற்றும் சலுகைகள்)
**Timing:** 07:00 – 09:30  
**Screen Visual:** Customer CRM Master (`10_crm_loyalty.png`), Tier configurations (Silver, Gold, Platinum), and Offers Manager (`11_offers_promotions.png`).

| On-Screen Action & Visual Cues | English Voiceover Narration | Tamil Voiceover Narration (தமிழ்) |
| :--- | :--- | :--- |
| **Visual:** Customer profile view showing lifetime spend ₹84,250, available points 420, tier: Gold.<br>**Text Overlay:** *Omnichannel CRM & Automated Loyalty Tiers* | Turn one-time shoppers into lifelong loyal customers. Our built-in CRM automatically tracks shopping frequency, lifetime spend, and assigns shoppers to Silver, Gold, or Platinum tiers. Regular customers can also maintain a secure Store Credit (Khata) account. | ஒருமுறை வரும் வாடிக்கையாளரை நிரந்தர வாடிக்கையாளராக மாற்றுங்கள். எங்களின் உள்ளமைக்கப்பட்ட வாடிக்கையாளர் மேலாண்மை முறை (CRM) அவர்களின் கொள்முதல் விவரங்களைக் கண்காணித்து, சில்வர், கோல்ட், பிளாட்டினம் என தரவரிசைப்படுத்துகிறது. நம்பிக்கையான வாடிக்கையாளர்களுக்கு காதா (Store Credit) கடன் கணக்கையும் நிர்வகிக்கலாம். |
| **Visual:** Offers Manager creates a weekend deal: "Buy 2 Detergents, Get 1 Fabric Softener Free" and "10% off on Biscuits above ₹300".<br>**Text Overlay:** *Dynamic Promotion Engine (BOGO, Combos, Tier Discounts)* | Run powerful supermarket promotions with ease. The Offer Engine supports Buy-One-Get-One, combo bundles, brand cashbacks, and basket-value discounts. Promotions trigger automatically at the cash counter with zero cashier manipulation. | சூப்பர்மார்க்கெட்டின் சிறப்பு சலுகைகளை மிக சுலபமாக உருவாக்குங்கள். ஒன்றிற்கு ஒன்று இலவசம் (BOGO), காம்போ சலுகைகள், பிராண்ட் கேஷ்பேக் மற்றும் குறிப்பிட்ட தொகைக்கு மேலான தள்ளுபடிகளை எளிதில் அமைக்கலாம். பில்லிங் செய்யும் போது இந்த சலுகைகள் தானாகவே கணக்கிடப்படும். |

---

## Chapter 5: Complete Financial Accounting (முழுமையான நிதி மற்றும் கணக்கியல்)
**Timing:** 09:30 – 12:00  
**Screen Visual:** Finance Dashboard (`12_finance_dashboard.png`), Profit & Loss statement (`12_finance_pl.png`), Balance Sheet, Supplier AP Aging, and Customer Ledgers.

| On-Screen Action & Visual Cues | English Voiceover Narration | Tamil Voiceover Narration (தமிழ்) |
| :--- | :--- | :--- |
| **Visual:** Accountant selects date range on Profit & Loss statement. Real-time Gross Margin, COGS, Operating Expenses, and Net Profit render instantly.<br>**Text Overlay:** *Automated Real-Time Double-Entry Accounting* | No third-party accounting software required. Every billing transaction, supplier bill, and stock adjustment posts directly to your Chart of Accounts in real-time double-entry compliance. Generate instant Profit & Loss and Balance Sheet statements at any second of the business day. | தனியாக வேறெந்த கணக்கு மென்பொருளும் தேவையில்லை. நீங்கள் போடும் ஒவ்வொரு விற்பனை பில், சப்ளையர் ரசீது மற்றும் சரக்கு சரிசெய்தல் அனைத்தும் பொதுப் பேரேட்டில் (General Ledger) தானாகப் பதியும். வணிக நாளின் எந்த நேரத்திலும் துல்லியமான லாப நஷ்ட அறிக்கை (P&L) மற்றும் இருப்புநிலைக் குறிப்பை (Balance Sheet) உடனடியாகப் பெறலாம். |
| **Visual:** AP Aging report shows supplier bills grouped by 0-30 days, 31-60 days, and 90+ days overdue. One-click payment voucher logged.<br>**Text Overlay:** *Supplier AP & Customer AR Aging Management* | Keep your cash flow under complete control. Track exactly what you owe to suppliers with AP Aging brackets, schedule vendor payments systematically, and monitor outstanding customer credit balances with automatic credit-limit enforcement. | உங்கள் பணப்புழக்கத்தை முழுமையாகக் கட்டுப்படுத்துங்கள். சப்ளையர்களுக்கு செலுத்த வேண்டிய தொகையை (AP Aging) கால அவகாச வாரியாகப் பார்க்கலாம். உரிய நேரத்தில் சப்ளையர்களுக்கு பணம் வழங்கி, வாடிக்கையாளர்களிடம் வரவேண்டிய பாக்கியையும் சுலபமாக வசூலிக்க முடியும். |

---

## Chapter 6: AI Co-Pilot & Executive Intelligence (ஏஐ ஸ்மார்ட் வழிகாட்டி)
**Timing:** 12:00 – 14:00  
**Screen Visual:** AI Executive Intelligence (`13_ai_executive.png`), AI Demand Forecaster (`13_ai_forecaster.png`), and Loss Prevention Anomaly Dashboard (`13_ai_loss_prevention.png`).

| On-Screen Action & Visual Cues | English Voiceover Narration | Tamil Voiceover Narration (தமிழ்) |
| :--- | :--- | :--- |
| **Visual:** Executive asks AI Co-Pilot: *"Which dairy products will stock out before Sunday?"* AI charts demand spikes and recommends reorder quantities.<br>**Text Overlay:** *Predictive Demand Forecasting & Auto-Reordering* | Take the guesswork out of procurement with our built-in AI Demand Forecaster. The AI analyzes historical sales, seasonal festivals, and weekday velocity to predict exactly when your shelves will run low, generating automatic Purchase Order recommendations before stockouts occur. | கணிப்புகளுக்கு இடமின்றி அறிவார்ந்த முடிவுகளை எடுங்கள். எங்களின் ஏஐ தேவை முன்னறிவிப்பு முறை (AI Demand Forecaster) முந்தைய விற்பனை மற்றும் திருவிழா காலங்களைக் கணக்கிட்டு, எந்தப் பொருட்கள் எப்போது தீர்ந்துபோகும் என்பதை முன்கூட்டியே எச்சரித்து, கொள்முதல் ஆணைகளை தானாகப் பரிந்துரைக்கும். |
| **Visual:** Loss prevention screen flags an anomaly: *"Cashier Terminal 2 performed 8 voided items between 7:00 PM and 8:00 PM"*. Manager inspects alert.<br>**Text Overlay:** *Loss Prevention & Anti-Fraud Surveillance* | Protect your supermarket profits against shrinkage. The AI Loss Prevention engine continuously audits cash drawers, high-value voids, excessive discounts, and off-hour returns, instantly alerting management to irregularities. | உங்கள் சூப்பர்மார்க்கெட் லாபத்தை திருட்டு மற்றும் முறைகேடுகளிலிருந்து பாதுகாத்துக் கொள்ளுங்கள். எங்களின் ஏஐ இழப்பு தடுப்பு முறை (Loss Prevention) பில் ரத்து செய்தல், அதீத தள்ளுபடிகள் மற்றும் பணப்பெட்டி முரண்பாடுகளைத் தொடர்ந்து கண்காணித்து நிர்வாகத்திற்கு உடனடியாக எச்சரிக்கை அனுப்புகிறது. |
| **Visual:** Final montage showing the mobile view, multi-store switch, customer checkout smile, and brand logo.<br>**Text Overlay:** *Empower Your Supermarket Today — Book a Live Demo* | From high-speed checkout to predictive AI intelligence, the Apple Supermarket POS & ERP Platform is your all-in-one retail engine. Contact us today to schedule your live store onboarding. | மின்னல் வேக பில்லிங் முதல் நவீன ஏஐ நுண்ணறிவு வரை — உங்கள் பல்பொருள் அங்காடியின் முழுமையான வெற்றிக்கு ஆப்பிள் சூப்பர்மார்க்கெட் ஈஆர்பி நிச்சயம் உதவும். இன்றே நேரடி செயல்விளக்கத்திற்கு (Live Demo) எங்களைத் தொடர்பு கொள்ளுங்கள்! |

---

## Summary of Production Checklist
1. **Video Master Asset:** Saved as `Documentation/videos/supermarket_erp_walkthrough.webm` (Full HD 720p/1080p, 30fps).
2. **Audio Track 1 (English):** Standard business English voiceover or browser narration with subtitle sync.
3. **Audio Track 2 (Tamil):** Professional Tamil voiceover with authentic supermarket terminology (பில்லிங், ஜி.ஆர்.என், ஸ்டாக் லெட்ஜர், காதா, லாப நஷ்ட அறிக்கை).
4. **Captions / Subtitles:** Synchronized dual-language subtitles embedded in the interactive player and downloadable as `.srt` or on-screen captions.
